varying vec3 v_position;
varying vec3 v_world_position;
varying vec3 v_normal;
varying vec2 v_uv;
varying vec4 v_color;

uniform vec4 u_color;
uniform sampler2D u_texture;
uniform float u_time;

//Light Info
uniform vec3 u_ambient_light;
uniform vec3 u_light_direction;
uniform vec3 u_pos_light;
uniform vec3 u_color_light;

void main()
{
	vec2 uv = v_uv;
	vec4 color = u_color * texture2D( u_texture, uv );

	vec3 light = u_ambient_light;

	vec3 N = normalize(v_normal);
	//vec3 lightpos = u_pos_light;
	vec3 light_direction = u_light_direction;

	//vec3 L = lightpos - v_world_position;
	vec3 L = light_direction;
	L= normalize(L);
	float NdotL = dot(N,L);
	NdotL = clamp(NdotL, 0.0,1.0);

	light += u_color_light*NdotL;
	color.xyz *= light;

	color.xyz = clamp(color.xyz, 0.0, 1.0);


	gl_FragColor = color;

}
